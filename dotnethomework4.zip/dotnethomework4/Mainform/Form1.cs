﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using OrderApp;
namespace Mainform
{
    public partial class Form1 : Form
    {
        public List<order> orders = new List<order>();
        Allorder orderseriv = new Allorder();


        public Form1()
        {
            InitializeComponent();
            order order1 = new order();
            
            

        }
        private DataTable GetData()
        {
            DataTable dt = new DataTable();
            DataColumn dc1 = new DataColumn("");
            return dt;
        }
        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void bindingSource1_CurrentChanged(object sender, EventArgs e)
        {
           
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            
            
        }

        private void button5_Click(object sender, EventArgs e)
        {
            neworder order = new neworder();
            order.ShowDialog();
        }

        private void bindingSource2_CurrentChanged(object sender, EventArgs e)
        {

        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
           
        }

        private void button3_Click(object sender, EventArgs e)
        {

        }
    }
}
