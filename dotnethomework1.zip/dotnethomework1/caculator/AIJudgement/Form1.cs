﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace AIJudgement
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        int x;
        int y;
        Random rnd = new Random();
        int result;
        string op;
        bool flag = true;
        bool flag2 = false;
        int score;
        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            timer1.Start();
            int c = rnd.Next(4);
            x = rnd.Next(100);
            y = rnd.Next(100);
            flag = false;
            switch (c)
            {
                case 0:
                    op = "+";
                    result = x + y;
                    break;
                case 1:
                    op = "-";
                    result = x - y;
                    break;
                case 2:
                    op = "*";
                    result = x * y;
                    break;
                case 3:
                    op = "/";
                    result = x / y;
                    break;
            }
            label2.Text = op;
            label1.Text = x.ToString();
            label3.Text = y.ToString();
            textBox1.Text = "";
        }

        private void button2_Click(object sender, EventArgs e)
        {
            timer1.Stop();
            flag2 = true;
            string str = textBox1.Text;
            if(flag)
            {
                MessageBox.Show("No Question here.");
            }
            if(str=="")
            {
                MessageBox.Show("nothing input");
            }
            string dipt = "" + x +op+ y + "=" + str;
            if (str == result.ToString())
            {
                dipt += "\tAccept";
                score++;
                label6.Text = score.ToString();
            }
            else dipt += "\tWrongAnswer";
            listBox1.Items.Add(dipt);
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            this.button1.PerformClick();
            MessageBox.Show("Failed to Complete it Timely");
        }

        private void listBox1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void label6_Click(object sender, EventArgs e)
        {

        }
    }
}
